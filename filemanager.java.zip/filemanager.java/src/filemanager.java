import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class filemanager {

    // Nombres de los archivos
    private static final String VISTAS_FILE = "vistas_admin.txt";
    private static final String COMPRAS_FILE = "compras_comprador.txt";
    private static final int MAX_VISTAS = 255;

    // --- MÉTODOS PARA LAS VISTAS DEL ADMINISTRADOR ---


    public boolean guardarVistas(String[] vistas) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(VISTAS_FILE))) {
            for (int i = 0; i < vistas.length; i++) {
                // Solo guarda las posiciones que tienen un nombre de vista (no nulo)
                if (vistas[i] != null) {
                    writer.println(i + ":" + vistas[i]);
                }
            }
            return true;
        } catch (IOException e) {
            System.err.println("Error al guardar las vistas: " + e.getMessage());
            return false;
        }
    }


    public String[] cargarVistas() {
        // Inicializa el arreglo con el tamaño máximo permitido (255)
        String[] vistas = new String[MAX_VISTAS];

        try (BufferedReader reader = new BufferedReader(new FileReader(VISTAS_FILE))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                // Divide la línea en índice y nombre de vista (Ej. "0:Messi" -> ["0", "Messi"])
                String[] partes = linea.split(":", 2);
                if (partes.length == 2) {
                    try {
                        int indice = Integer.parseInt(partes[0].trim());
                        String nombre = partes[1].trim();

                        // Asegura que el índice esté dentro del rango permitido
                        if (indice >= 0 && indice < MAX_VISTAS) {
                            vistas[indice] = nombre;
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Advertencia: Formato de índice inválido en la línea: " + linea);
                    }
                }
            }
        } catch (FileNotFoundException e) {

            System.out.println("Archivo de vistas no encontrado. Iniciando con 0 vistas.");
        } catch (IOException e) {
            System.err.println("Error al cargar las vistas: " + e.getMessage());
        }

        return vistas;
    }

    // --- MÉTODOS PARA LAS COMPRAS DEL COMPRADOR ---


    public boolean guardarCompras(Object[][] compras) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(COMPRAS_FILE))) {
            for (Object[] compra : compras) {

                if (compra[0] != null) {

                    writer.println(compra[0] + "," + compra[1] + "," + compra[2]);
                }
            }
            return true;
        } catch (IOException e) {
            System.err.println("Error al guardar las compras: " + e.getMessage());
            return false;
        }
    }


    public Object[][] cargarCompras() {
        // Usamos una lista temporal para cargar, ya que no sabemos cuántas compras hay.
        List<Object[]> listaCompras = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(COMPRAS_FILE))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                // Divide la línea por comas (Ej. "0,Messi,1" -> ["0", "Messi", "1"])
                String[] partes = linea.split(",", 3);
                if (partes.length == 3) {
                    try {
                        // Se almacena el código como Integer y la cantidad como Integer
                        Object[] compra = new Object[3];
                        compra[0] = Integer.parseInt(partes[0].trim()); // Código
                        compra[1] = partes[1].trim(); // Nombre
                        compra[2] = Integer.parseInt(partes[2].trim()); // Cantidad
                        listaCompras.add(compra);

                    } catch (NumberFormatException e) {
                        System.err.println("Advertencia: Formato numérico inválido en la línea de compra: " + linea);
                    }
                }
            }
        } catch (FileNotFoundException e) {

            System.out.println("Archivo de compras no encontrado. Iniciando con 0 compras.");
        } catch (IOException e) {
            System.err.println("Error al cargar las compras: " + e.getMessage());
        }

        Object[][] compras = new Object[MAX_VISTAS][3];
        for (int i = 0; i < listaCompras.size() && i < MAX_VISTAS; i++) {
            compras[i] = listaCompras.get(i);
        }

        return compras;
    }
}
